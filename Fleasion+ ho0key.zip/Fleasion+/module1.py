# fleasion_gui.py
# A complete Tkinter UI for Fleasion that wraps the existing terminal logic in main.py.
# Requirements: Python 3.10+, Tkinter (bundled), your existing Fleasion folder layout.
#
# Folder expectations (same as main.py):
#   assets/
#     games/<GameName>/{assets.json,cached_files/,code.py,log.txt,...}
#     community/<TweakName>/{assets.json,cached_files/,code.py,log.txt,...}
#     custom/storage/cached_files/
#     presets/*.txt
#   storage/settings.json
#
# It imports functions from main.py so behavior matches Fleasion’s TUI exactly.
# You can run it with:  python fleasion_gui.py
#
# NOTE: On Windows, the "Blocker" feature modifies hosts file and needs admin privileges,
# just like in main.py.

import os
import sys
import json
import re
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

# Ensure we can import your existing main.py (this file sits next to main.py)
HERE = os.path.abspath(os.path.dirname(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

# ----- Import Fleasion core functions from main.py -----
# These are used throughout so the UI matches TUI behavior.
try:
    from main import (
        replacer,
        traverse_json,
        collect_all_values,
        export,
        load_settings,
        asset_dirs,
        find_keys_for_results,
        background_autolaunch,
    )
except Exception as e:
    print("Failed to import from main.py. Make sure fleasion_gui.py is next to main.py.\n", e)
    raise

# Optional helpers in main.py, not strictly required everywhere
try:
    from main import games_game_pre  # used by TUI; we scan dirs directly instead
except Exception:
    games_game_pre = None

# ----------------- Constants & paths -----------------
ASSETS_DIR = os.path.join(HERE, "assets")
GAMES_DIR = os.path.join(ASSETS_DIR, "games")
COMMUNITY_DIR = os.path.join(ASSETS_DIR, "community")
CUSTOM_CACHED = os.path.join(ASSETS_DIR, "custom", "storage", "cached_files")
PRESETS_DIR = os.path.join(ASSETS_DIR, "presets")
SETTINGS_PATH = os.path.join(HERE, "storage", "settings.json")
ROBLOX_TEMP_HTTP = os.path.join(os.getenv("TEMP", ""), "roblox", "http")

# ----------------- Utility -----------------
def safe_load_json(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return None
    except json.JSONDecodeError as e:
        messagebox.showerror("JSON Error", f"{path}\n\n{e}")
        return None

def list_subfolders(path):
    try:
        return [f for f in os.listdir(path) if os.path.isdir(os.path.join(path, f))]
    except FileNotFoundError:
        return []

def list_cached_files(game_root):
    cf = os.path.join(game_root, "cached_files")
    if not os.path.isdir(cf):
        return []
    try:
        return sorted([f for f in os.listdir(cf) if os.path.isfile(os.path.join(cf, f))])
    except Exception:
        return []

def ensure_dirs():
    os.makedirs(PRESETS_DIR, exist_ok=True)
    os.makedirs(CUSTOM_CACHED, exist_ok=True)

def flatten_values(obj):
    # Similar to collect_all_values from main.py, returns a flat list
    vals = collect_all_values(obj)
    # Normalize to a list of hashes
    flat = []
    for v in vals:
        if isinstance(v, list):
            flat.extend(v)
        else:
            flat.append(v)
    return flat

# ----------------- Tree rendering of assets.json -----------------
def fill_tree_from_json(tree: ttk.Treeview, parent, data):
    """
    Recursively fills a Treeview with nested dict/list content.
    Leaves are those whose value is a string or list of strings (hashes).
    """
    if isinstance(data, dict):
        for k, v in data.items():
            node = tree.insert(parent, "end", text=str(k), values=("dict", ""))
            fill_tree_from_json(tree, node, v)
    elif isinstance(data, list):
        # If it's a list of hashes, make it a leaf
        # Else enumerate
        if data and all(isinstance(x, str) for x in data):
            # Represent as a join (but real data is stored in tags)
            leaf = tree.insert(parent, "end", text=f"[{len(data)} hashes]", values=("leaf_list", ", ".join(data)))
            tree.set(leaf, column="kind", value="leaf_list")
        else:
            for i, v in enumerate(data):
                node = tree.insert(parent, "end", text=f"[{i}]", values=("list", ""))
                fill_tree_from_json(tree, node, v)
    else:
        # Primitive leaf (string hash)
        tree.insert(parent, "end", text=str(data), values=("leaf_value", str(data)))

def collect_leaf_hashes(tree: ttk.Treeview, item_id, parent_data):
    """
    Given a selected item, walk its subtree, extract all hashes (strings) or list of strings.
    """
    # Get children; if none, check the leaf itself
    kids = tree.get_children(item_id)
    if not kids:
        kind = tree.set(item_id, "kind")
        label = tree.item(item_id, "text")
        if kind == "leaf_value":
            return [label]
        if kind == "leaf_list":
            # tree shows a human string; we need the actual list.
            # Safest approach is to refetch from the original JSON using the path.
            # To keep it simple we parse the CSV we stored in the "value" column.
            raw = tree.set(item_id, "value")
            hashes = [h.strip() for h in raw.split(",") if h.strip()]
            return hashes
        # Non-leaf with no children? Then it is a primitive string.
        if isinstance(label, str):
            return [label]
        return []
    else:
        collected = []
        for kid in kids:
            collected.extend(collect_leaf_hashes(tree, kid, parent_data))
        return collected

# ----------------- Main Application -----------------
class FleasionApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Fleasion UI")
        self.geometry("1100x700")
        self.minsize(1000, 640)

        ensure_dirs()

        # Load settings through main.py, and keep a copy in memory for toggles
        self.settings = safe_load_json(SETTINGS_PATH) or {}
        try:
            # Let main.py validate & warm up background features
            load_settings()
            background_autolaunch()  # same behavior as TUI
        except Exception:
            pass

        self.current_root = None        # path to selected game/tweak folder
        self.current_json = None        # loaded assets.json for current_root
        self.display_names = bool(self.settings.get("display_names", False))

        # Session log label (top), main content area (center), status bar (bottom)
        self._build_layout()
        self._build_sidebar()
        self.show_page("home")

    # ----- Layout -----
    def _build_layout(self):
        # Top bar
        top = tk.Frame(self, bd=0, relief="flat")
        top.pack(side="top", fill="x")
        self.path_var = tk.StringVar(value="Welcome to Fleasion")
        tk.Label(top, textvariable=self.path_var, anchor="w").pack(side="left", padx=8, pady=8)

        # Body with sidebar + main content
        body = tk.Frame(self)
        body.pack(side="top", fill="both", expand=True)
        self.sidebar = tk.Frame(body, width=230)
        self.sidebar.pack(side="left", fill="y")
        self.main = tk.Frame(body)
        self.main.pack(side="left", fill="both", expand=True)

        # Status bar
        self.status = tk.StringVar(value="Ready.")
        tk.Label(self, textvariable=self.status, anchor="w", bd=1, relief="sunken").pack(side="bottom", fill="x")

    def _build_sidebar(self):
        # Navigation buttons
        nav = [
            ("Games", lambda: self.show_page("games")),
            ("Community", lambda: self.show_page("community")),
            ("Custom", lambda: self.show_page("custom")),
            ("Presets", lambda: self.show_page("presets")),
            ("Previewer", lambda: self.show_page("previewer")),
            ("Blocker", lambda: self.show_page("blocker")),
            ("Cache Settings", lambda: self.show_page("cache")),
            ("Fleasion Settings", lambda: self.show_page("settings")),
            ("Credits", lambda: self.show_page("credits")),
        ]
        tk.Label(self.sidebar, text="Menu", font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=10, pady=(12, 6))
        for label, cmd in nav:
            b = ttk.Button(self.sidebar, text=label, command=cmd)
            b.pack(fill="x", padx=10, pady=4)

    # ----- Navigation -----
    def clear_main(self):
        for w in self.main.winfo_children():
            w.destroy()

    def show_page(self, page):
        self.clear_main()
        self.status.set(f"Opened {page.title()}")

        if page == "home":
            self._build_home()
        elif page == "games":
            self._build_games_or_community(GAMES_DIR, title="Games")
        elif page == "community":
            self._build_games_or_community(COMMUNITY_DIR, title="Community Tweaks")
        elif page == "custom":
            self._build_custom()
        elif page == "presets":
            self._build_presets()
        elif page == "previewer":
            self._build_previewer()
        elif page == "blocker":
            self._build_blocker()
        elif page == "cache":
            self._build_cache_settings()
        elif page == "settings":
            self._build_settings()
        elif page == "credits":
            self._build_credits()
        else:
            self._build_home()

    # ----- Pages -----
    def _build_home(self):
        frame = self.main
        tk.Label(frame, text="Fleasion – GUI", font=("Segoe UI", 18, "bold")).pack(pady=(40, 8))
        tk.Label(frame, text="Pick a section from the left to begin.", font=("Segoe UI", 12)).pack()

    def _build_games_or_community(self, base_dir, title="Games"):
        self.path_var.set(title)

        left = tk.Frame(self.main)
        left.pack(side="left", fill="y", padx=8, pady=8)
        right = tk.Frame(self.main)
        right.pack(side="left", fill="both", expand=True, padx=(0, 8), pady=8)

        tk.Label(left, text=f"{title} list", font=("Segoe UI", 12, "bold")).pack(anchor="w", pady=(0, 6))
        self.listbox = tk.Listbox(left, height=18)
        self.listbox.pack(fill="y", expand=False)
        for folder in list_subfolders(base_dir):
            self.listbox.insert("end", folder)

        actions = tk.Frame(left)
        actions.pack(fill="x", pady=8)
        ttk.Button(actions, text=f"Open {title[:-1] if title.endswith('s') else title}",
                   command=lambda: self._open_game_or_tweak(base_dir)).pack(fill="x")

        # Right side: assets tree + cached files + controls
        header = tk.Frame(right)
        header.pack(fill="x")
        self.sel_name = tk.StringVar(value="Nothing selected")
        tk.Label(header, textvariable=self.sel_name, font=("Segoe UI", 12, "bold")).pack(side="left")

        # Tree + cached files
        split = tk.PanedWindow(right, orient="horizontal")
        split.pack(fill="both", expand=True, pady=6)

        # Assets tree
        tree_frame = tk.Frame(split)
        split.add(tree_frame, stretch="always")
        tk.Label(tree_frame, text="Assets (from assets.json)").pack(anchor="w")
        columns = ("kind", "value")
        self.tree = ttk.Treeview(tree_frame, columns=columns, show="tree")
        # store extra info in "kind" and "value" columns
        self.tree["displaycolumns"] = ()  # hide columns visually; we use tree.set to store metadata
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", lambda e: self._on_tree_select())

        # Cached files list
        #cached_frame = tk.Frame(split)
        #split.add(cached_frame, stretch="always")
        #tk.Label(cached_frame, text="Available replacements (cached_files)").pack(anchor="w")
        #self.cached_list = tk.Listbox(cached_frame)
        #self.cached_list.pack(fill="both", expand=True)

        preview_frame = tk.Frame(split, bd=2, relief="groove")
        split.add(preview_frame, stretch="always")  # Add to split on the right
        tk.Label(preview_frame, text="Preview").pack(anchor="n")
        self.preview_label = tk.Label(preview_frame)
        self.preview_label.pack(fill="both", expand=True)

        controls = tk.Frame(right)
        controls.pack(fill="x", pady=(0, 8))
        self.change_btn = ttk.Button(controls, text="Apply Replacement", command=self._do_replacement, state="disabled")
        self.change_btn.pack(side="left")

        ttk.Button(controls, text="Refresh cached_files", command=self._refresh_cached_list).pack(side="left", padx=6)

    def _open_game_or_tweak(self, base_dir):
        sel = self.listbox.curselection()
        if not sel:
            messagebox.showinfo("Select one", "Please select a folder from the list.")
            return
        name = self.listbox.get(sel[0])
        self.sel_name.set(f"Selected: {name}")
        root = os.path.join(base_dir, name)
        self.current_root = root
        self.current_json = safe_load_json(os.path.join(root, "assets.json"))
        self._fill_tree()
        self._refresh_cached_list()
        self.status.set(f"Loaded {name}")

    def _fill_tree(self):
        # clear
        for i in self.tree.get_children(""):
            self.tree.delete(i)
        if not self.current_json:
            return
        fill_tree_from_json(self.tree, "", self.current_json)
        self.change_btn.config(state="disabled")

    def _refresh_cached_list(self):
        self.cached_list.delete(0, "end")
        if not self.current_root:
            return
        for f in list_cached_files(self.current_root):
            self.cached_list.insert("end", f)

    def _on_tree_select(self):
        self.change_btn.config(state="normal")

        sel = self.tree.selection()
        if not sel or not self.current_root:
            return

        # get all hashes under this node
        results = []
        for item in sel:
            results.extend(collect_leaf_hashes(self.tree, item, self.current_json))

        if not results:
            return

        # Only show preview for the first hash
        h = results[0]
        preview_path = os.path.join(self.current_root, "cached_files", f"{h}.png")
        if os.path.exists(preview_path):
            try:
                from PIL import Image, ImageTk
                img = Image.open(preview_path)
                img.thumbnail((256, 256))  # resize to fit sidebar
                self.preview_img = ImageTk.PhotoImage(img)
                self.preview_label.config(image=self.preview_img, text="")
            except Exception as e:
                self.preview_label.config(image="", text=f"(Error loading preview)\n{e}")
        else:
            self.preview_label.config(image="", text=f"No preview for:\n{h}")

    def _do_replacement(self):
        # Collect selected hashes from the selected node (and its children)
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("Select asset", "Select a key/leaf in the assets tree.")
            return
        # collect all leaf hashes beneath selection(s)
        results = []
        for item in sel:
            results.extend(collect_leaf_hashes(self.tree, item, self.current_json))
        results = [h for h in results if isinstance(h, str) and h.strip()]
        if not results:
            messagebox.showerror("No hashes", "Could not determine any asset hashes under the selection.")
            return

        # Pick replacement from cached_files
        csel = self.cached_list.curselection()
        if not csel:
            messagebox.showinfo("Pick replacement", "Select a replacement from cached_files.")
            return
        replacement = self.cached_list.get(csel[0])

        # Call Fleasion replacer (main.py)
        try:
            # Pass game_pre so replacer searches this game's cached_files first.
            game_pre = os.path.join(self.current_root, "")
            replacer(results, replacement, temp=False, download=False, game_pre=game_pre, display_names=self.display_names)
            self.status.set(f"Replaced {len(results)} file(s) with '{replacement}'")
        except Exception as e:
            messagebox.showerror("Replacement failed", str(e))

    # ----- Custom -----
    def _build_custom(self):
        self.path_var.set("Custom")
        frame = self.main

        tk.Label(frame, text="Custom Replacement", font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=8, pady=(8, 2))

        a = tk.Frame(frame)
        a.pack(fill="x", padx=8)
        tk.Label(a, text="Asset hash(es):").pack(side="left")
        self.custom_hashes = tk.Entry(a)
        self.custom_hashes.pack(side="left", fill="x", expand=True, padx=(6, 0))
        tk.Label(a, text=" (comma-separated)").pack(side="left", padx=8)

        b = tk.Frame(frame)
        b.pack(fill="x", padx=8, pady=6)
        tk.Label(b, text="Replacement filename:").pack(side="left")
        self.custom_repl = tk.Entry(b)
        self.custom_repl.pack(side="left", fill="x", expand=True, padx=(6, 0))
        ttk.Button(b, text="Browse cached_files...", command=self._browse_custom_cached).pack(side="left", padx=6)

        btns = tk.Frame(frame)
        btns.pack(fill="x", padx=8, pady=8)
        ttk.Button(btns, text="Apply from Fleasion Assets", command=lambda: self._custom_apply(temp=False, download=False)).pack(side="left")
        ttk.Button(btns, text="Apply from Roblox Temp (also copy to custom cache)", command=lambda: self._custom_apply(temp=True, download=True)).pack(side="left", padx=6)

        # helper listing for custom cache
        tk.Label(frame, text="assets/custom/storage/cached_files", font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=8, pady=(8, 2))
        lb = tk.Listbox(frame, height=12)
        lb.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        for f in list_cached_files(os.path.join(ASSETS_DIR, "custom", "storage")):
            # We only want the nested cached_files folder; function returns [] for that path,
            # so we’ll enumerate directly:
            pass
        for f in sorted(os.listdir(CUSTOM_CACHED)):
            if os.path.isfile(os.path.join(CUSTOM_CACHED, f)):
                lb.insert("end", f)

    def _browse_custom_cached(self):
        # Let user pick a file name from custom cached_files to populate the entry
        try:
            fn = filedialog.askopenfilename(initialdir=CUSTOM_CACHED, title="Pick a replacement file (name only is used)")
            if fn:
                self.custom_repl.delete(0, "end")
                self.custom_repl.insert(0, os.path.basename(fn))
        except Exception:
            pass

    def _custom_apply(self, temp=False, download=False):
        hashes = [h.strip() for h in self.custom_hashes.get().split(",") if h.strip()]
        if not hashes:
            messagebox.showinfo("Missing", "Enter at least one asset hash.")
            return
        repl = self.custom_repl.get().strip()
        if not repl:
            messagebox.showinfo("Missing", "Enter a replacement filename.")
            return
        try:
            replacer(hashes, repl, temp=temp, download=download, game_pre="", display_names=self.display_names)
            src = "Roblox Temp" if temp else "Fleasion Assets"
            self.status.set(f"Custom: replaced {len(hashes)} asset(s) from {src} using '{repl}'")
        except Exception as e:
            messagebox.showerror("Custom replace failed", str(e))

    # ----- Presets -----
    def _build_presets(self):
        self.path_var.set("Presets")
        frame = self.main
        tk.Label(frame, text="Presets", font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=8, pady=(8, 4))

        top = tk.Frame(frame)
        top.pack(fill="x", padx=8)

        ttk.Button(top, text="Load Preset", command=self._preset_load).pack(side="left")
        ttk.Button(top, text="Create Preset from Session", command=self._preset_create_from_session).pack(side="left", padx=6)
        ttk.Button(top, text="View / Delete Preset", command=self._preset_view_delete).pack(side="left", padx=6)

        self.presets_lb = tk.Listbox(frame, height=14)
        self.presets_lb.pack(fill="both", expand=True, padx=8, pady=8)
        self._refresh_presets()

    def _refresh_presets(self):
        self.presets_lb.delete(0, "end")
        for f in sorted(os.listdir(PRESETS_DIR)):
            if f.endswith(".txt"):
                self.presets_lb.insert("end", f)

    def _pick_preset_filename(self, prompt="Choose a preset from the list."):
        sel = self.presets_lb.curselection()
        if not sel:
            messagebox.showinfo("Pick a preset", prompt)
            return None
        return self.presets_lb.get(sel[0])

    def _preset_load(self):
        name = self._pick_preset_filename()
        if not name:
            return
        path = os.path.join(PREETS_DIR := PRESETS_DIR, name)
        try:
            with open(path, "r", encoding="utf-8") as f:
                preset_choice = eval(f.read(), {}, {})  # same approach as main.py (ast.literal_eval in main.py)
            # Apply using main.replacer for each pair
            for i in range(0, len(preset_choice), 2):
                result = preset_choice[i]
                result2 = preset_choice[i + 1]
                replacer(result, result2, temp=False, download=False, game_pre="", display_names=self.display_names)
            self.status.set(f"Loaded preset: {os.path.splitext(name)[0]}")
        except Exception as e:
            messagebox.showerror("Load failed", str(e))

    def _preset_create_from_session(self):
        # In main.py, "session_history" is appended to by replacer calls. We can snapshot that file-less
        # by asking the user for a name and writing the same representation.
        dlg = tk.Toplevel(self)
        dlg.title("Create Preset")
        tk.Label(dlg, text="Preset name:").pack(side="left", padx=8, pady=8)
        ent = tk.Entry(dlg)
        ent.pack(side="left", padx=(0, 8), pady=8)

        def save_it():
            name = ent.get().strip()
            if not name:
                return
            invalid = r'[<>:"/\\|?*\x00-\x1F]'
            if re.search(invalid, name):
                messagebox.showerror("Invalid name", f"Name must not contain: {invalid}")
                return
            path = os.path.join(PRESETS_DIR, f"{name}.txt")
            try:
                # Import session_history from main so we mirror TUI behavior
                from main import session_history
                with open(path, "w", encoding="utf-8") as f:
                    f.write(str(session_history))
                self._refresh_presets()
                dlg.destroy()
                self.status.set(f"Saved preset: {name}")
            except Exception as e:
                messagebox.showerror("Save failed", str(e))

        ttk.Button(dlg, text="Save", command=save_it).pack(side="left", padx=(0, 8), pady=8)

    def _preset_view_delete(self):
        name = self._pick_preset_filename()
        if not name:
            return
        path = os.path.join(PRESETS_DIR, name)

        dlg = tk.Toplevel(self)
        dlg.title(f"Preset: {name}")

        txt = tk.Text(dlg, width=80, height=24)
        txt.pack(fill="both", expand=True)
        try:
            with open(path, "r", encoding="utf-8") as f:
                content = f.read()
                txt.insert("1.0", content)
        except Exception as e:
            txt.insert("1.0", f"Error: {e}")

        bar = tk.Frame(dlg)
        bar.pack(fill="x")
        def delete_it():
            if messagebox.askyesno("Delete", f"Delete {name}?"):
                try:
                    os.remove(path)
                    dlg.destroy()
                    self._refresh_presets()
                except Exception as e:
                    messagebox.showerror("Delete failed", str(e))
        ttk.Button(bar, text="Delete", command=delete_it).pack(side="left", padx=6, pady=6)

    # ----- Previewer -----
    def _build_previewer(self):
        self.path_var.set("Previewer")
        frame = self.main
        tk.Label(frame, text="Preview", font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=8, pady=(8, 2))

        chooser = tk.Frame(frame)
        chooser.pack(fill="x", padx=8)

        tk.Label(chooser, text="Source:").pack(side="left")
        src = tk.StringVar(value="temp")
        for label, val in [("Temp", "temp"), ("Games", "games"), ("Community", "community"), ("Custom", "custom")]:
            ttk.Radiobutton(chooser, text=label, value=val, variable=src).pack(side="left", padx=(6, 0))

        holder = tk.Frame(frame)
        holder.pack(fill="both", expand=True, padx=8, pady=8)

        # For games/community we need to pick a folder + a leaf asset to preview
        # For temp/custom we just need a hash/file
        path_frame = tk.Frame(holder)
        path_frame.pack(fill="x")
        tk.Label(path_frame, text="Hash / File:").pack(side="left")
        ent = tk.Entry(path_frame)
        ent.pack(side="left", fill="x", expand=True, padx=(6, 0))

        def browse_custom():
            fn = filedialog.askopenfilename(initialdir=CUSTOM_CACHED, title="Pick a cached file to preview")
            if fn:
                ent.delete(0, "end")
                ent.insert(0, os.path.basename(fn))

        ttk.Button(path_frame, text="Browse custom cached_files...", command=browse_custom).pack(side="left", padx=6)

        ttk.Separator(holder, orient="horizontal").pack(fill="x", pady=8)

        tk.Label(holder, text="(Optional) For Games/Community: choose a folder then select a leaf to auto-fill").pack(anchor="w")
        sub = tk.Frame(holder)
        sub.pack(fill="both", expand=True)
        left = tk.Frame(sub)
        left.pack(side="left", fill="y", padx=(0, 8))
        right = tk.Frame(sub)
        right.pack(side="left", fill="both", expand=True)

        lb = tk.Listbox(left, height=12)
        lb.pack(fill="y")
        lb_label = tk.StringVar(value="(None)")
        tk.Label(left, textvariable=lb_label).pack()

        # Tree for picked game/community
        columns = ("kind", "value")
        tv = ttk.Treeview(right, columns=columns, show="tree")
        tv["displaycolumns"] = ()
        tv.pack(fill="both", expand=True)

        def refresh_lb():
            base = GAMES_DIR if src.get() == "games" else COMMUNITY_DIR
            lb.delete(0, "end")
            for f in list_subfolders(base):
                lb.insert("end", f)
            lb_label.set(base)

        def on_pick_folder():
            sel = lb.curselection()
            if not sel:
                return
            base = GAMES_DIR if src.get() == "games" else COMMUNITY_DIR
            name = lb.get(sel[0])
            root = os.path.join(base, name)
            data = safe_load_json(os.path.join(root, "assets.json"))
            # fill tree
            for i in tv.get_children(""):
                tv.delete(i)
            if data:
                fill_tree_from_json(tv, "", data)

        def on_tree_dblclick(_evt=None):
            sel = tv.selection()
            if not sel:
                return
            hashes = []
            for it in sel:
                hashes.extend(collect_leaf_hashes(tv, it, None))
            # For preview, we only need one file path
            if not hashes:
                return
            # Use the first hash to auto-fill
            ent.delete(0, "end")
            ent.insert(0, hashes[0])

        ttk.Button(left, text="Load Folders", command=refresh_lb).pack(fill="x", pady=6)
        ttk.Button(left, text="Open Folder", command=on_pick_folder).pack(fill="x")

        tv.bind("<Double-1>", on_tree_dblclick)

        # Preview button
        def do_preview():
            s = src.get()
            val = ent.get().strip()
            if not val:
                messagebox.showinfo("Missing", "Enter a hash/file first.")
                return
            try:
                if s == "temp":
                    path = os.path.join(ROBLOX_TEMP_HTTP, val)
                elif s == "games":
                    # If val is a hash, preview from current selection’s cached_files—ask user to confirm
                    sel = lb.curselection()
                    if not sel:
                        messagebox.showinfo("Pick", "Choose a game folder on the left.")
                        return
                    root = os.path.join(GAMES_DIR, lb.get(sel[0]))
                    path = os.path.join(root, "cached_files", val)
                elif s == "community":
                    sel = lb.curselection()
                    if not sel:
                        messagebox.showinfo("Pick", "Choose a community folder on the left.")
                        return
                    root = os.path.join(COMMUNITY_DIR, lb.get(sel[0]))
                    path = os.path.join(root, "cached_files", val)
                else:
                    path = os.path.join(CUSTOM_CACHED, val)

                export(path)  # main.py function; handles temp file and opens
                self.status.set(f"Previewed {os.path.basename(path)}")
            except Exception as e:
                messagebox.showerror("Preview failed", str(e))

        ttk.Button(frame, text="Preview", command=do_preview).pack(pady=6)

    # ----- Blocker (hosts file toggler) -----
    def _build_blocker(self):
        self.path_var.set("Blocker")
        frame = self.main
        tk.Label(frame, text="Blocker", font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=8, pady=(8, 2))
        tk.Label(frame, text="This modifies your hosts file to block/unblock c0..c7 / t0..t7 rbxcdn domains.\nRun the app as Administrator on Windows.",
                 justify="left").pack(anchor="w", padx=8, pady=(0, 8))

        entries = tk.Text(frame, height=6)
        entries.pack(fill="x", padx=8)
        entries.insert("1.0", "Enter items like c0, c1, t0, t1 ... one per line. Type exactly as above.\n")

        def apply_block():
            items = [ln.strip().lower() for ln in entries.get("1.0", "end").splitlines() if ln.strip()]
            # Implement the same logic as main.py’s blocker for toggling/commenting lines
            FILE_PATH = r"C:\Windows\System32\drivers\etc\hosts"
            try:
                with open(FILE_PATH, "r", encoding="utf-8") as f:
                    content = f.read()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to read hosts: {e}")
                return

            modified = content
            for entry in items:
                target = f"127.0.0.1 {entry}.rbxcdn.com"
                commented = f"#{target}"
                if commented in modified:
                    modified = modified.replace(commented, target)  # (Uncomment) block
                elif target in modified:
                    modified = modified.replace(target, commented)  # (Comment) unblock
                else:
                    modified += f"\n{target}"  # newly block

            try:
                with open(FILE_PATH, "w", encoding="utf-8") as f:
                    f.write(modified)
                messagebox.showinfo("Done", "Updated hosts.")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to write hosts: {e}")

        ttk.Button(frame, text="Apply", command=apply_block).pack(pady=8)

    # ----- Cache Settings -----
    def _build_cache_settings(self):
        self.path_var.set("Cache Settings")
        frame = self.main
        tk.Label(frame, text="Cache Settings", font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=8, pady=(8, 2))

        ttk.Button(frame, text="Revert Session Replacements", command=self._revert_session).pack(anchor="w", padx=8, pady=4)
        ttk.Button(frame, text="Clear Full Cache (Roblox Temp)", command=self._clear_full_cache).pack(anchor="w", padx=8, pady=4)
        ttk.Button(frame, text="Undo Specific Change (pick from a Game's asset)", command=self._undo_specific_dialog).pack(anchor="w", padx=8, pady=4)

    def _revert_session(self):
        # Mirror main.py’s approach: delete files that were written in this session from Temp.
        try:
            from main import session_history
        except Exception:
            session_history = []
        if not session_history:
            messagebox.showinfo("Empty", "Session is already empty, try making a change!")
            return

        # Flatten only names (some can be lists) and delete in Temp
        to_delete = []
        def flatten(lst):
            for item in lst:
                if isinstance(item, list):
                    yield from flatten(item)
                else:
                    yield item

        for item in session_history:
            if isinstance(item, list):
                to_delete.extend(list(flatten(item)))
        # Delete
        errors = []
        for fname in to_delete:
            fpath = os.path.join(ROBLOX_TEMP_HTTP, fname)
            try:
                if os.path.exists(fpath):
                    os.remove(fpath)
            except Exception as e:
                errors.append((fname, str(e)))
        # Clear history in main.py
        try:
            import main as main_mod
            main_mod.session_history = []
        except Exception:
            pass

        if errors:
            messagebox.showwarning("Done with warnings", f"Some files not deleted:\n" + "\n".join(f"{n}: {e}" for n, e in errors[:10]))
        else:
            messagebox.showinfo("Done", "Reverted session replacements.")

    def _clear_full_cache(self):
        if not os.path.isdir(ROBLOX_TEMP_HTTP):
            messagebox.showinfo("Temp empty", f"{ROBLOX_TEMP_HTTP} does not exist or is empty.")
            return
        errors = []
        for name in os.listdir(ROBLOX_TEMP_HTTP):
            p = os.path.join(ROBLOX_TEMP_HTTP, name)
            try:
                if os.path.isdir(p):
                    # shouldn't be subdirs normally, but handle it
                    for root, dirs, files in os.walk(p, topdown=False):
                        for f in files:
                            os.remove(os.path.join(root, f))
                        for d in dirs:
                            os.rmdir(os.path.join(root, d))
                    os.rmdir(p)
                else:
                    os.remove(p)
            except Exception as e:
                errors.append((name, str(e)))
        if errors:
            messagebox.showwarning("Done with warnings", f"Some entries could not be removed:\n" + "\n".join(f"{n}: {e}" for n, e in errors[:10]))
        else:
            messagebox.showinfo("Done", "Cleared Roblox Temp cache.")

    def _undo_specific_dialog(self):
        dlg = tk.Toplevel(self)
        dlg.title("Undo specific (Games)")

        left = tk.Frame(dlg)
        left.pack(side="left", fill="y", padx=6, pady=6)
        right = tk.Frame(dlg)
        right.pack(side="left", fill="both", expand=True, padx=(0, 6), pady=6)

        lb = tk.Listbox(left, height=12)
        lb.pack(fill="y")
        for f in list_subfolders(GAMES_DIR):
            lb.insert("end", f)

        columns = ("kind", "value")
        tv = ttk.Treeview(right, columns=columns, show="tree")
        tv["displaycolumns"] = ()
        tv.pack(fill="both", expand=True)

        def open_folder():
            sel = lb.curselection()
            if not sel:
                return
            name = lb.get(sel[0])
            root = os.path.join(GAMES_DIR, name)
            data = safe_load_json(os.path.join(root, "assets.json"))
            for i in tv.get_children(""):
                tv.delete(i)
            if data:
                fill_tree_from_json(tv, "", data)

        ttk.Button(left, text="Open", command=open_folder).pack(fill="x", pady=6)

        def undo_selected():
            sel = tv.selection()
            if not sel:
                return
            hashes = []
            for it in sel:
                hashes.extend(collect_leaf_hashes(tv, it, None))
            deleted = []
            for h in hashes:
                target = os.path.join(ROBLOX_TEMP_HTTP, h)
                try:
                    if os.path.exists(target):
                        os.remove(target)
                        deleted.append(h)
                except:
                    pass
            messagebox.showinfo("Undo", f"Reset {len(deleted)} file(s).")
            dlg.destroy()

        ttk.Button(dlg, text="Undo selected", command=undo_selected).pack(side="bottom", pady=6)

    # ----- Settings -----
    def _build_settings(self):
        self.path_var.set("Fleasion Settings")
        frame = self.main
        tk.Label(frame, text="Fleasion Settings", font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=8, pady=(8, 2))

        # Display names toggle
        dn = tk.BooleanVar(value=self.settings.get("display_names", False))
        def on_dn():
            self.settings["display_names"] = bool(dn.get())
            self.display_names = bool(dn.get())
        ttk.Checkbutton(frame, text="Display changes as names (instead of hashes)", variable=dn, command=on_dn).pack(anchor="w", padx=8, pady=4)

        # Startup launch & preset(s)
        sl = tk.BooleanVar(value=self.settings.get("startup_launch", False))
        presets_var = tk.StringVar(value=", ".join(self.settings.get("startup_preset", [])))
        tk.Label(frame, text="Presets to apply on Roblox launch (comma-separated names, no .txt):").pack(anchor="w", padx=8, pady=(8, 2))
        ent = tk.Entry(frame, textvariable=presets_var)
        ent.pack(fill="x", padx=8)
        ttk.Checkbutton(frame, text="Apply preset(s) on launch", variable=sl).pack(anchor="w", padx=8, pady=4)

        # Default bootstrapper (string)
        tk.Label(frame, text="Default Bootstrapper:").pack(anchor="w", padx=8, pady=(8, 2))
        bs = tk.StringVar(value=self.settings.get("bootstrapper", "Bloxstrap"))
        ent_bs = tk.Entry(frame, textvariable=bs)
        ent_bs.pack(fill="x", padx=8)

        def save_settings():
            self.settings["startup_launch"] = bool(sl.get())
            raw = ent.get().strip()
            self.settings["startup_preset"] = [p.strip() for p in raw.split(",") if p.strip()]
            self.settings["bootstrapper"] = ent_bs.get().strip() or "Bloxstrap"
            try:
                with open(SETTINGS_PATH, "w", encoding="utf-8") as f:
                    json.dump(self.settings, f, indent=4)
                messagebox.showinfo("Saved", "Settings updated.")
                # Refresh main’s in-memory settings too
                try:
                    load_settings()
                except Exception:
                    pass
            except Exception as e:
                messagebox.showerror("Save failed", str(e))

        ttk.Button(frame, text="Save Settings", command=save_settings).pack(anchor="w", padx=8, pady=8)

    # ----- Credits -----
    def _build_credits(self):
        self.path_var.set("Credits")
        frame = self.main
        tk.Label(frame, text="Credits", font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=8, pady=(8, 2))
        msg = (
            "Fleasion – GUI wrapper\n"
            "• Uses Fleasion core logic from main.py (© your project)\n"
            "• Thanks to the Fleasion community\n"
        )
        tk.Label(frame, text=msg, justify="left").pack(anchor="w", padx=8)

# ----------------- Run -----------------
if __name__ == "__main__":
    app = FleasionApp()
    app.mainloop()
