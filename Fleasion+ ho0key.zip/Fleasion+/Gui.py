#!/usr/bin/env python3
"""
Full GUI script (customtkinter) implementing:
- Sidebar with 5 pages
- Page 2: Game Runner with hardcoded menu definitions + dynamic JSON options
- Replacement logic via push/backbone/replacer
- OLED black theme with pink buttons, hover effects, left-aligned text
"""

import os
import sys
import json
import shutil
import urllib.request
import importlib.util
import customtkinter as ctk
from colorama import Fore, Style, init as colorama_init

colorama_init(autoreset=True)

# -----------------------
# GLOBALS and defaults
# -----------------------
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")  # we will override button colors

# default (will be set by choosing a folder)
game_pre = os.path.normpath(os.path.join("assets", "games", "Phantom Forces"))
json_file_path = os.path.normpath(os.path.join(game_pre, "assets.json"))
game_code = os.path.normpath(os.path.join(game_pre, "code.py"))

start_key = ""
start_key2 = ""
addon = None
addon2 = None
skip = False
display_names = []
session_history = []
json_data = {}

# ---------- Hardcoded submenu definitions ----------
# Each item can have:
# - label: shown to user
# - addon: what to replace (string or list)
# - addon2: direct replacement (optional)
# - start_key2: name of JSON key to let user pick replacement from assets.json
MENU_DEFINITIONS = {
    "Custom": [
        { "label": "Custom - manual (not implemented)", "addon": None }
    ],
    "Sights": [
        {"label": "Reticle tweaks", "start_key2": "reticle replacement"},
        {"label": "Sight model tweaks", "start_key2": "sight model"},
        {"label": "Ballistics tracker tweaks", "addon": "66a3dd9c1d934ad0ffb5d45729c44250", "start_key2": None},
    ],
    "Arm model tweaks": [
        {"label": "Remove options (choose replace)", "start_key": "arm models", "addon2": "5873cfba79134ecfec6658f559d8f320"},
        {"label": "Reflective sleeves (multiple)", "addon": ["ac95c4dbcb1a5ec120bc64b369d41fc3","da00c2a2bba51d962b29423c25b28bd3","60a99d5ab2dbf24f654b93b731f720c7","6e649a3ad144c63298bafb5f0583ed7d"], "addon2": "remove"},
        {"label": "Bone arms (submenu)", "start_key2": "arm bone options"}
    ],
    "Sleeves": [
        {"label": "Default sleeves", "addon": None}
    ],
    "No textures": [
        {"label": "Remove textures", "start_key2": "textures"}
    ],
    "Default skyboxes": [
        {"label": "Default skyboxes", "start_key2": "skyboxes"}
    ],
    "Gun skins TEMPORARILY DEPRECATED": [
        {"label": "Gun skins (deprecated)", "start_key2": "skins"}
    ],
    "Gun Sounds": [
        {"label": "Replacement sounds", "start_key2": "replacement sounds"}
    ],
    "Gun smoke": [
        {"label": "Pink smoke", "addon": "602e49f80440cdb859fab7182ea4bb23", "addon2": "5c4932441500b62a3218bbbabe45a117"},
        {"label": "Blue smoke", "addon": "602e49f80440cdb859fab7182ea4bb23", "addon2": "38342d3214ad04067e03106bdff41914"},
    ],
    "Hit tweaks": [
        {"label": "Hitmarkers", "addon": "097165b476243d2095ef0a256320b06a", "start_key2": "hitmarker"},
        {"label": "Hit sounds", "addon": "a177d2c00abd3e550b873d76c97ad960", "start_key2": "replacement sounds"},
    ],
    "Grenade tweaks": [
        {"label": "RGD model tweaks", "start_key2": "grenades"},
        {"label": "Bundle tweaks", "start_key2": "grenades"}
    ],
    "Misc tweaks": [
        {"label": "M21 Garand Ping", "addon": ["07fe5c19cdd350a4922412d00d567edd","17bb7bd20bf6e1b41214619d16698ff4"], "start_key2": "replacement sounds"},
        {"label": "Remove Bullet Casing Sounds", "addon": ["7b11fe3312b0801492d3e0f8dce62043","853395973e94bf11a1c9edb8110da786"], "start_key2": None}
    ],
    "Grenade Warning": [
        {"label": "Grenade Warning images", "start_key2": "images"}
    ],
    "Ho0keys tweaks": [
        {"label": "Knuckles 2 perc", "addon": ["bf4a84852a2300227a8c7ecbc593d6d1","bf51e6e8a19a4364734d36418f013808","b87d3643e63269f553e020761986b0e3"], "start_key2": None},
        {"label": "Remove CQR grip", "addon": ["14f489ef172a8899f571595c61013a91","9d5d3ec6c7d9a466c888a9bd60cea222"], "start_key2": None},
        {"label": "Custom Thumbnails", "addon": ["00b9f533f9739f829ecb4d72e60ec841","0a725ed7927051ed526b31158e2ce213"], "start_key2": "images"},
        {"label": "Remove aug a3 screws?", "addon": ["5d57fd2bdabbe4721ff06d5166337b8e","5c0f06ef0a10bf4607d64ad86aed1158"], "start_key2": None}
    ],
}
BACKGROUND_TWEAKS = {
    1: ("3fc9141fc7c1167c575b9361a98f04c0", "5873cfba79134ecfec6658f559d8f320"),
    2: ("2eaae4fe3a9fce967af993d27ad68d52", "5873cfba79134ecfec6658f559d8f320"),
    3: ("2eaae4fe3a9fce967af993d27ad68d52", "5873cfba79134ecfec6658f559d8f320"),
    4: ("7d5652167ec33ed349e569a55a398705", "75205be5a167842c7ed931d9d5a904ca"),
    5: (["a883a2373ad6931556dce946c50c3690","5a2a41b0da7ec98bf25780bb3f5d071f"], "75205be5a167842c7ed931d9d5a904ca"),
    6: ('71718d43e373e3633f4ff3b70ec19cf7', 'GH_Black_Border'),
    7: ('0f621cf9866d643421f0292a85f9be98', 'b99ee82264ed6bfdd815f2f568abff3a'),
    8: ('0ba25a5e810da83a31db384ade65aad2', '5873cfba79134ecfec6658f559d8f320'),
    9: ('2d41ab1e5a2d3cdbf0e1856a5274e4e8', '5873cfba79134ecfec6658f559d8f320'),
    10: ('99c0b33c613f8e56c8119dd7c209d3bf', '5873cfba79134ecfec6658f559d8f320')
}


TOP_LEVEL_MENU = [
    "Custom", "Sights", "Arm model tweaks", "Sleeves", "No textures",
    "Default skyboxes", "Gun skins TEMPORARILY DEPRECATED", "Gun Sounds",
    "Gun smoke", "Hit tweaks", "Grenade tweaks", "Misc tweaks",
    "Grenade Warning", "Ho0keys tweaks"
]

# -----------------------
# Utility functions
# -----------------------
def show_background_tweaks(pending_addon=None, parent_callback=None):
    """Show the 10 background tweak buttons for Sights submenu items."""
    clear_scrollable_frame()
    gui_print("Choose a background tweak:")

    for idx in range(1, 11):
        a, a2 = BACKGROUND_TWEAKS[idx]
        def make_pick(ad=a, ad2=a2):
            def pick():
                gui_print(f"Applying background tweak #{idx}")
                backbone(json_data, None, None, pending_addon or ad, ad2, False, game_pre, display_names)
            return pick
        btn = ctk.CTkButton(
            scrollable_frame,
            text=f"{idx}: {str(a)[:40]}{'...' if len(str(a))>40 else ''}",
            fg_color="#FF69B4",
            hover_color="#FF85C1",
            text_color="black",
            corner_radius=6,
            anchor="w",
            command=make_pick()
        )
        btn.pack(pady=4, padx=6, fill="x")

    # Back button
    back_btn = ctk.CTkButton(
        scrollable_frame,
        text="⬅ Back",
        fg_color="#FF69B4",
        hover_color="#FF85C1",
        text_color="black",
        corner_radius=6,
        anchor="w",
        command=parent_callback if parent_callback else lambda: open_submenu("Sights")
    )
    back_btn.pack(pady=8, padx=6, fill="x")

def gui_print(msg):
    """Append message to output_box (thread-safe not needed here)."""
    output_box.insert("end", str(msg) + "\n")
    output_box.see("end")

def load_json_for_game(game_folder):
    """Load assets.json for the selected game."""
    global json_data, json_file_path, game_pre, game_code
    game_pre = os.path.normpath(os.path.join("assets", "games", game_folder))
    json_file_path = os.path.normpath(os.path.join(game_pre, "assets.json"))
    game_code = os.path.normpath(os.path.join(game_pre, "code.py"))
    if os.path.exists(json_file_path):
        try:
            with open(json_file_path, "r", encoding="utf-8") as f:
                json_data = json.load(f)
            gui_print(f"Loaded JSON: {os.path.abspath(json_file_path)}")
            gui_print(f"Top-level keys: {list(json_data.keys())}")
        except Exception as e:
            gui_print(f"{Fore.RED}Error loading JSON: {e}{Style.RESET_ALL}")
            json_data = {}
    else:
        gui_print(f"{Fore.RED}assets.json not found at: {json_file_path}{Style.RESET_ALL}")
        json_data = {}

def traverse_json_simple(data, start_key):
    """Return list of (name, value) for data[start_key] if dict, else []"""
    if not data or start_key not in data:
        return []
    val = data[start_key]
    if isinstance(val, dict):
        return list(val.items())   # list of (key, value)
    return []

def collect_all_values(obj):
    values = []
    if isinstance(obj, dict):
        for v in obj.values():
            values.extend(collect_all_values(v))
    elif isinstance(obj, list):
        for item in obj:
            values.extend(collect_all_values(item))
    else:
        values.append(obj)
    return values

# -----------------------
# Replacer / backbone
# -----------------------
def replacer(result_list, result2, temp=False, download=False, game_pre_local=None, display_names_local=None):
    """
    result_list: list of filenames/hashes to replace (strings)
    result2: replacement filename/hash (string)
    game_pre_local: path to the game's folder, e.g. assets/games/Phantom Forces
    """
    # Normalize game folder
    if not game_pre_local:
        game_pre_local = game_pre

    # folder_path where Roblox temp files should be placed (target)
    folder_path = os.path.normpath(os.path.join(game_pre_local, "cached_files"))
    os.makedirs(folder_path, exist_ok=True)

    session_history.append((result_list, result2))

    # First look for result2 file in game cached_files, then search other games
    def find_cached_file_path():
        # primary: inside the same game folder
        candidate = os.path.normpath(os.path.join(game_pre_local, "cached_files", result2))
        if os.path.exists(candidate):
            return os.path.normpath(os.path.join(game_pre_local, "cached_files"))

        # fallback: search other asset folders for cached_files containing result2
        search_dirs = ["assets/games", "assets/community", "assets/custom"]
        for base_dir in search_dirs:
            if not os.path.exists(base_dir):
                continue
            for subfolder in os.listdir(base_dir):
                cached_files_path = os.path.normpath(os.path.join(base_dir, subfolder, "cached_files"))
                target = os.path.normpath(os.path.join(cached_files_path, result2))
                if os.path.exists(target):
                    return cached_files_path
        return None

    local_cached_files_path = find_cached_file_path()
    if not local_cached_files_path:
        gui_print(f"{Fore.RED}{result2} not found in any cached_files (searched near {game_pre_local}).{Style.RESET_ALL}")
        return False

    copy_file_path = os.path.normpath(os.path.join(local_cached_files_path, result2))
    if not os.path.exists(copy_file_path):
        gui_print(f"{Fore.RED}Source file not found: {copy_file_path}{Style.RESET_ALL}")
        return False

    # Replace every entry in result_list by copying the replacement file to the game's temp folder with the required name
    success_count = 0
    for file_to_replace in result_list:
        try:
            target_file_path = os.path.normpath(os.path.join(folder_path, file_to_replace))
            shutil.copy(copy_file_path, target_file_path)
            gui_print(f"Replaced '{file_to_replace}' with '{result2}' -> {target_file_path}")
            success_count += 1
        except Exception as e:
            gui_print(f"{Fore.RED}Error copying {copy_file_path} -> {target_file_path}: {e}{Style.RESET_ALL}")
    return success_count > 0

def backbone(json_data_local, start_key_local, start_key2_local, addon_local, addon2_local, skip_local, game_pre_local, display_names_local):
    """
    Apply the replacement logic. This mirrors the CLI backbone behavior but adapted for GUI.
    - addon_local may be a string or list of strings (the replacees)
    - addon2_local should be a single string (replacement) — if it's list we use first element
    - If addon_local is None and start_key_local provided: we try to resolve from json_data
    """
    if skip_local:
        gui_print("Skipped (skip flag set).")
        return

    # Resolve replacees (result) from addon_local or from json_data via traverse_json
    if addon_local is None and start_key_local:
        # try to collect values from json using start_key_local
        resolved = traverse_json_simple(json_data_local, start_key_local)
        # flatten values
        result = []
        for k, v in resolved:
            if isinstance(v, list):
                result.extend(v)
            else:
                result.append(v)
    else:
        # ensure list
        if not isinstance(addon_local, list):
            result = [addon_local] if addon_local is not None else []
        else:
            result = addon_local

    # result is a list of strings/hashes to replace
    result = [r for r in result if r]  # filter None/empty

    if not result:
        gui_print(f"{Fore.YELLOW}No replaceable items resolved.{Style.RESET_ALL}")
        return

    # Determine replacement result2
    resolved_result2 = addon2_local
    if resolved_result2 is None and start_key2_local:
        # The GUI flow should have already set addon2 by selecting from JSON; fallback: pick first value from json
        items = traverse_json_simple(json_data_local, start_key2_local)
        if items:
            # items is list of (k, v)
            first = items[0][1]
            resolved_result2 = first if not isinstance(first, list) else (first[0] if first else None)

    if not resolved_result2:
        gui_print(f"{Fore.RED}No replacement (addon2) resolved for start_key2='{start_key2_local}'{Style.RESET_ALL}")
        return

    # If addon2_local was a list, take first
    if isinstance(resolved_result2, list):
        resolved_result2 = resolved_result2[0]

    # Apply replacer for each entry of 'result' — replacer expects a list of replacees (we can pass singles)
    # If result is a list of many, we apply replacer once per element (this matches original CLI behavior)
    for entry in result:
        if entry is None:
            continue
        replacer([entry], resolved_result2, temp=False, download=False, game_pre_local=game_pre_local, display_names_local=display_names_local)

    gui_print(f"{Fore.CYAN}Applied replacement -> replacement hash: {resolved_result2}{Style.RESET_ALL}")

# -----------------------
# GUI: Page 2 behavior
# -----------------------
def open_submenu(category):
    """Open submenu for a top-level category. Shows submenu items from MENU_DEFINITIONS."""
    clear_scrollable_frame()
    if category == "Sights" and label in ["Reticle tweaks", "Sight model tweaks"]:
        # show the hardcoded background tweaks submenu
        show_background_tweaks(pending_addon=ad, parent_callback=lambda: open_submenu("Sights"))

    gui_print(f"Category: {category}")

    items = MENU_DEFINITIONS.get(category, [])
    if not items:
        gui_print(f"{Fore.YELLOW}No submenu items for {category}{Style.RESET_ALL}")
        return

    # create buttons for each submenu item
    for idx, item in enumerate(items):
        label = item.get("label", f"item-{idx}")
        a_addon = item.get("addon", None)
        a_addon2 = item.get("addon2", None)
        a_start_key2 = item.get("start_key2", None)
        a_start_key = item.get("start_key", None)

        # button callback closure
        def make_callback(ad=a_addon, ad2=a_addon2, sk2=a_start_key2, sk=a_start_key, it=item):
            def callback():
                gui_print(f"Selected submenu: {label}")
                # If the submenu provides a start_key2, we will show dynamic options from json_data[sk2]
                if sk2:
                    # Save pending addon (replacee) and present JSON choices for replacement
                    pending_addon = ad
                    # If addon's None, we'll attempt to use start_key (if provided by item) or inform user
                    if not pending_addon and it.get("start_key"):
                        # If the submenu wanted to choose replacees from JSON as well:
                        gui_print(f"Selecting replacees from JSON key: {it.get('start_key')}")
                        # In our simplified GUI, using JSON for both replacee & replacement is uncommon; warn
                        gui_print(f"{Fore.YELLOW}Note: submenu expects 'addon' to be set for replacees. Using provided item value.{Style.RESET_ALL}")
                    # Show dynamic JSON options and when user picks one, the code will call backbone
                    show_json_options_for_key(sk2, pending_addon)
                else:
                    # If direct addon2 present, perform immediate replacement (addon may be list)
                    if ad2:
                        # apply replacement directly
                        backbone(json_data, item.get("start_key", None), None, ad, ad2, False, game_pre, display_names)
                    elif ad:
                        # If only addon present but no addon2/start_key2 -> it may be a list of replacees that should be processed with a default replacement (rare)
                        gui_print(f"{Fore.YELLOW}This submenu has an 'addon' but no replacement specified. Nothing done.{Style.RESET_ALL}")
                    else:
                        gui_print(f"{Fore.YELLOW}No actionable data for this submenu item.{Style.RESET_ALL}")
            return callback

        btn = ctk.CTkButton(
            scrollable_frame,
            text=label,
            fg_color="#FF69B4",
            hover_color="#FF85C1",
            text_color="black",
            corner_radius=6,
            anchor="w",
            command=make_callback()
        )
        btn.pack(pady=6, padx=6, fill="x")

    # back button
    back_btn = ctk.CTkButton(
        scrollable_frame,
        text="⬅ Back",
        fg_color="#FF69B4",
        hover_color="#FF85C1",
        text_color="black",
        corner_radius=6,
        anchor="w",
        command=top_level_menu
    )
    back_btn.pack(pady=8, padx=6, fill="x")


def show_json_options_for_key(key_name, pending_addon):
    """
    Present buttons for every key/value in json_data[key_name].
    When user picks one, set addon2 to that value and call backbone with pending_addon as replacee.
    """
    clear_scrollable_frame()

    if not json_data:
        gui_print(f"{Fore.RED}No JSON loaded. Select a game first.{Style.RESET_ALL}")
        return

    if key_name not in json_data:
        gui_print(f"{Fore.RED}Invalid start_key2: {key_name}{Style.RESET_ALL}")
        gui_print(f"Available keys: {list(json_data.keys())}")
        return

    entries = traverse_json_simple(json_data, key_name)  # list of (key, value)
    if not entries:
        gui_print(f"{Fore.YELLOW}No entries under {key_name}{Style.RESET_ALL}")
        return

    gui_print(f"Choose replacement from '{key_name}' ({len(entries)} items)")

    # build buttons for each entry
    for k, v in entries:
        def make_pick(k=k, v=v):
            def pick():
                chosen_key = k
                chosen_value = v
                # chosen_value might be string or list; we accept string or first element of list
                if isinstance(chosen_value, list):
                    chosen_value_use = chosen_value[0] if chosen_value else None
                else:
                    chosen_value_use = chosen_value

                gui_print(f"Chosen replacement: {chosen_key} -> {chosen_value_use}")

                # If pending_addon is a list or string, call backbone to apply replacement
                if pending_addon:
                    # If pending_addon is a list: apply each entry replacing with chosen_value_use
                    backbone(json_data, None, None, pending_addon, chosen_value_use, False, game_pre, display_names)
                else:
                    # If pending_addon NOT set: maybe user expects to pick replacees from JSON as well.
                    gui_print(f"{Fore.YELLOW}No pending 'addon' provided; nothing applied. (If desired, choose submenu item that sets 'addon').{Style.RESET_ALL}")

            return pick

        btn = ctk.CTkButton(
            scrollable_frame,
            text=f"{k}  ({str(v)[:40]}{'...' if len(str(v))>40 else ''})",
            fg_color="#FF69B4",
            hover_color="#FF85C1",
            text_color="black",
            corner_radius=6,
            anchor="w",
            command=make_pick()
        )
        btn.pack(pady=4, padx=6, fill="x")

    # Back button to submenu
    back_btn = ctk.CTkButton(
        scrollable_frame,
        text="⬅ Back",
        fg_color="#FF69B4",
        hover_color="#FF85C1",
        text_color="black",
        corner_radius=6,
        anchor="w",
        command=top_level_menu
    )
    back_btn.pack(pady=8, padx=6, fill="x")


# -----------------------
# GUI: helpers & layout
# -----------------------
def clear_scrollable_frame():
    for w in scrollable_frame.winfo_children():
        w.destroy()

def create_top_level_buttons():
    clear_scrollable_frame()
    for cat in TOP_LEVEL_MENU:
        btn = ctk.CTkButton(
            scrollable_frame,
            text=cat,
            fg_color="#FF69B4",
            hover_color="#FF85C1",
            text_color="black",
            corner_radius=6,
            anchor="w",
            command=lambda c=cat: open_submenu(c)
        )
        btn.pack(pady=6, padx=6, fill="x")

# -----------------------
# GUI windows & setup
# -----------------------
app = ctk.CTk()
app.geometry("1200x800")
app.title("Fleasion GUI - OLED Pink")
app.configure(fg_color="black")

# Sidebar
sidebar = ctk.CTkFrame(app, width=200, corner_radius=0, fg_color="black")
sidebar.pack(side="left", fill="y")

# Content
content = ctk.CTkFrame(app, corner_radius=0, fg_color="black")
content.pack(side="right", fill="both", expand=True)

# Pages dict
pages = {}
buttons = {}
active_page = None

def show_page(name):
    global active_page
    for p in pages.values():
        p.pack_forget()
    pages[name].pack(fill="both", expand=True, padx=20, pady=20)
    for btn_name, btn in buttons.items():
        btn.configure(fg_color="#FF69B4" if btn_name == name else "transparent")
    active_page = name

# -----------------------
# Page 1: Welcome / Game selection
# -----------------------
page1 = ctk.CTkFrame(content, corner_radius=10, fg_color="#111111")

ctk.CTkLabel(page1, text="Welcome to Fleasion (GUI)", font=("Arial", 30), text_color="#FF69B4").pack(pady=12)
ctk.CTkLabel(page1, text="Select a game below to load its assets.json", font=("Arial", 14)).pack(pady=6)

# Games dropdown (list folders in assets/games)
games_root = os.path.join("assets", "games")
games_folders = []
if os.path.exists(games_root):
    games_folders = [f for f in os.listdir(games_root) if os.path.isdir(os.path.join(games_root, f))]
else:
    gui_print(f"{Fore.YELLOW}No 'assets/games' directory found. Create it and add your games.{Style.RESET_ALL}")

game_var = ctk.StringVar(value=games_folders[0] if games_folders else "")

game_dropdown = ctk.CTkOptionMenu(page1, values=games_folders, variable=game_var)
game_dropdown.pack(pady=8)

def on_game_select():
    selected = game_var.get()
    if not selected:
        gui_print("No game selected.")
        return
    load_json_for_game(selected)
    gui_print(f"Selected game: {selected}")
    # after selecting, show top-level menu in page2 if user opens it
    show_page("page2")
    top_level_menu()

ctk.CTkButton(page1, text="Load Game", command=on_game_select, fg_color="#FF69B4", hover_color="#FF85C1", text_color="black").pack(pady=10)

pages["page1"] = page1

# -----------------------
# Page 2: Game Runner (main interactive)
# -----------------------
page2 = ctk.CTkFrame(content, corner_radius=10, fg_color="#111111")
ctk.CTkLabel(page2, text="Game Runner", font=("Arial", 22), text_color="#FF69B4").pack(pady=8)

# Info area + load status
output_box = ctk.CTkTextbox(page2, width=700, height=140, fg_color="#111111")
output_box.pack(pady=8)

# Scrollable options frame
scrollable_frame = ctk.CTkScrollableFrame(page2, width=700, height=420, fg_color="#222222")
scrollable_frame.pack(pady=8, padx=8, fill="both", expand=True)

def top_level_menu():
    # refresh load if game_var changed
    sel = game_var.get()
    if sel:
        load_json_for_game(sel)
    gui_print("Top-level menu:")
    create_top_level_buttons()

pages["page2"] = page2

# -----------------------
# Page 3: Presets / Settings placeholder
# -----------------------
page3 = ctk.CTkFrame(content, corner_radius=10, fg_color="#111111")
ctk.CTkLabel(page3, text="Presets / Tools", font=("Arial", 22), text_color="#FF69B4").pack(pady=12)
ctk.CTkLabel(page3, text="(Presets and extra tools would appear here)", font=("Arial", 12)).pack(pady=6)
pages["page3"] = page3

# -----------------------
# Page 4: Controls / Progress
# -----------------------
page4 = ctk.CTkFrame(content, corner_radius=10, fg_color="#111111")
ctk.CTkLabel(page4, text="Controls", font=("Arial", 22), text_color="#FF69B4").pack(pady=12)
progress = ctk.CTkProgressBar(page4, width=400)
progress.pack(pady=8)
progress.set(0.0)
pages["page4"] = page4

# -----------------------
# Page 5: Credits
# -----------------------
page5 = ctk.CTkFrame(content, corner_radius=10, fg_color="#111111")
ctk.CTkLabel(page5, text="Credits", font=("Arial", 22), text_color="#FF69B4").pack(pady=12)
ctk.CTkLabel(page5, text="UI by you. Logic adapted from your CLI.", font=("Arial", 12)).pack(pady=6)
pages["page5"] = page5

# -----------------------
# Sidebar buttons
# -----------------------
button_labels = {
    "page1": "🏠 Home",
    "page2": "📝 Games",
    "page3": "📂 Presets",
    "page4": "⚙️ Controls",
    "page5": "📊 Credits"
}

for name, label_text in button_labels.items():
    btn = ctk.CTkButton(
        sidebar,
        text=label_text,
        command=lambda n=name: show_page(n),
        fg_color="transparent",
        hover_color="#222222",
        text_color="white",
        corner_radius=6,
        anchor="w"
    )
    btn.pack(pady=10, padx=12, fill="x")
    buttons[name] = btn

# Show default page
show_page("page1")

# -----------------------
# Final note: start app
# -----------------------
if __name__ == "__main__":
    # Preload initial json_data if default exists
    if os.path.exists(json_file_path):
        try:
            with open(json_file_path, "r", encoding="utf-8") as f:
                json_data = json.load(f)
        except Exception:
            json_data = {}
    app.mainloop()
